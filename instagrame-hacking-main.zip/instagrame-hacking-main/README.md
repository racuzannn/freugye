#                         instagrame-hacking
![White-Basic-Presentation-Template-2-1536x781](https://user-images.githubusercontent.com/88341460/230964227-15b94298-64db-4e24-b775-0b78b854398b.png)

instagrame-hacking is a bash based script which is officially made to test password strength of instagram account from termux with bruteforce attack and This tool works on both rooted Android device and Non-rooted Android device.
# Tested On Hackers 🏴
* Kali Linux

* BlackArch Linux

* Ubuntu

* Kali Nethunter

* Termux

* Parrot OS
# Installation 🛠️
# Kali Linux/Ubuntu/Parrot OS:
    sudo apt-get update
    sudo apt-get install git
    sudo apt install python3
    git clone https://github.com/akashblackhat/instagrame-hacking.git
    ls
    cd instagrame-hacking.py
    ls
    sudo python3 instagrame-hacking.py
# Termux Installation :
    apt-get update -y
    apt-get upgrade -y
    pkg install python -y 
    pkg install python3 -y
    pkg install git -y
    pip install lolcat
    git clone https://github.com/akashblackhat/instagrame-hacking.git
    ls
    cd instagrame-hacking.py
    python3 instagrame-hacking.py
 # Note
* Now you need internet connection to continue further process...
* Note:- Don't delete any of the scripts included in core files
* Open new session and start TOR (tor or vpn) before starting the attack
## 🔗 ***Check this***
### Subscribe our channel on youtube:
https://youtu.be/VIvsSMsk1C0
 
## 👥 ***Join***
### Facebook group:
https://www.facebook.com/AKASHBLACKHAT

### Instagram:

https://instagram.com/akashblackhat?igshid=ZDdkNTZiNTM=

### My GitHub ID link:
https://github.com/akashblackhat

### 📢 Warning
***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
Phone Number Information tool not responsible for misuse and for illegal purposes.
Use it only for Pentest or Educational purpose 🏴 !!!
Hacking is not a crime (: ..Pull requests are always welcome.. :)
# Happy Hacking ( Privacy & Security No Such Things Exists in digital World, We Can Hack Everything )
    
